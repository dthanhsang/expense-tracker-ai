import 'dart:io';
import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ExpenseMasterApp());
}

enum UserRole { user, admin }

class UserAccount {
  final String email;
  final String name;
  final UserRole role;
  UserAccount({required this.email, required this.name, required this.role});
}

enum ExpenseCategory {
  food('Ăn uống', CupertinoIcons.cart_fill, Color(0xFFFF6B6B)),
  transport('Di chuyển', CupertinoIcons.car_detailed, Color(0xFF4ECDC4)),
  shopping('Mua sắm', CupertinoIcons.bag_fill, Color(0xFFFFBE0B)),
  bills('Hóa đơn', CupertinoIcons.doc_text_fill, Color(0xFF8338EC)),
  other('Khác', CupertinoIcons.square_grid_2x2_fill, Color(0xFF3A86FF));

  final String label;
  final IconData icon;
  final Color color;
  const ExpenseCategory(this.label, this.icon, this.color);
}

class ExpenseTransaction {
  final String id;
  final String title;
  final double amount;
  final DateTime date;
  final ExpenseCategory category;
  final String? receiptImagePath;

  ExpenseTransaction({
    required this.id,
    required this.title,
    required this.amount,
    required this.date,
    required this.category,
    this.receiptImagePath,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'amount': amount,
        'date': date.toIso8601String(),
        'category': category.name,
        'receiptImagePath': receiptImagePath,
      };

  factory ExpenseTransaction.fromJson(Map<String, dynamic> json) {
    return ExpenseTransaction(
      id: json['id'],
      title: json['title'],
      amount: (json['amount'] as num).toDouble(),
      date: DateTime.parse(json['date']),
      category: ExpenseCategory.values.firstWhere(
        (e) => e.name == json['category'],
        orElse: () => ExpenseCategory.other,
      ),
      receiptImagePath: json['receiptImagePath'],
    );
  }
}

class ExpenseMasterApp extends StatelessWidget {
  const ExpenseMasterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Expense Master AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF2F4F7),
        colorSchemeSeed: const Color(0xFF0066FF),
      ),
      home: const AuthScreen(),
    );
  }
}

// ================= AUTH SCREEN =================
class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool _isLogin = true;
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _nameCtrl = TextEditingController();
  bool _loading = false;

  void _submit() {
    final email = _emailCtrl.text.trim();
    final pass = _passCtrl.text.trim();
    if (email.isEmpty || pass.isEmpty) return;

    setState(() => _loading = true);
    Future.delayed(const Duration(milliseconds: 600), () {
      setState(() => _loading = false);
      UserRole role = email.toLowerCase().contains('admin') ? UserRole.admin : UserRole.user;
      UserAccount account = UserAccount(
        email: email,
        name: _nameCtrl.text.isEmpty ? (role == UserRole.admin ? 'Quản trị viên' : 'Thành viên') : _nameCtrl.text,
        role: role,
      );
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => MainNavigationScreen(user: account)));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(colors: [Color(0xFF0066FF), Color(0xFF0038A8)], begin: Alignment.topCenter, end: Alignment.bottomCenter),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.95),
                borderRadius: BorderRadius.circular(24),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 20, offset: const Offset(0, 10))],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(CupertinoIcons.chart_pie_fill, size: 56, color: Color(0xFF0066FF)),
                  const SizedBox(height: 16),
                  Text(_isLogin ? 'Chào mừng trở lại!' : 'Tạo tài khoản mới', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  const Text('Quản lý tài chính thông minh với AI', style: TextStyle(color: Colors.grey, fontSize: 13)),
                  const SizedBox(height: 24),
                  if (!_isLogin) ...[
                    CupertinoTextField(controller: _nameCtrl, placeholder: 'Họ và tên', padding: const EdgeInsets.all(14)),
                    const SizedBox(height: 12),
                  ],
                  CupertinoTextField(controller: _emailCtrl, placeholder: 'Email (Nhập "admin" để test quyền Admin)', padding: const EdgeInsets.all(14)),
                  const SizedBox(height: 12),
                  CupertinoTextField(controller: _passCtrl, placeholder: 'Mật khẩu', obscureText: true, padding: const EdgeInsets.all(14)),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: CupertinoButton.filled(
                      onPressed: _loading ? null : _submit,
                      child: _loading ? const CupertinoActivityIndicator(color: Colors.white) : Text(_isLogin ? 'Đăng Nhập' : 'Đăng Ký'),
                    ),
                  ),
                  const SizedBox(height: 14),
                  CupertinoButton(
                    child: Text(_isLogin ? 'Chưa có tài khoản? Đăng ký ngay' : 'Đã có tài khoản? Đăng nhập', style: const TextStyle(fontSize: 13, color: Color(0xFF0066FF))),
                    onPressed: () => setState(() => _isLogin = !_isLogin),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ================= MAIN NAVIGATION (BOTTOM NAV BAR + FLOATING AI) =================
class MainNavigationScreen extends StatefulWidget {
  final UserAccount user;
  const MainNavigationScreen({super.key, required this.user});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _currentIndex = 0;
  List<ExpenseTransaction> _txs = [];
  final double _budget = 15000000;
  final NumberFormat _formatter = NumberFormat.currency(locale: 'vi_VN', symbol: '₫');

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString('tx_${widget.user.email}');
    if (data != null) {
      setState(() => _txs = (jsonDecode(data) as List).map((e) => ExpenseTransaction.fromJson(e)).toList());
    }
  }

  Future<void> _saveData() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString('tx_${widget.user.email}', jsonEncode(_txs.map((e) => e.toJson()).toList()));
  }

  void _add(ExpenseTransaction tx) {
    setState(() => _txs.insert(0, tx));
    _saveData();
  }

  double get _spent => _txs.fold(0, (sum, i) => sum + i.amount);

  @override
  Widget build(BuildContext context) {
    final isAdmin = widget.user.role == UserRole.admin;

    final List<Widget> pages = [
      DashboardTab(user: widget.user, txs: _txs, spent: _spent, budget: _budget, formatter: _formatter, onAdd: _add),
      AiTab(txs: _txs, spent: _spent, budget: _budget, formatter: _formatter),
    ];

    return Scaffold(
      body: Stack(
        children: [
          isAdmin ? AdminDashboardView(user: widget.user, txs: _txs) : pages[_currentIndex],

          // Bong bóng AI nổi ở góc phải màn hình (chỉ hiện ở tab trang chủ của User)
          if (!isAdmin && _currentIndex == 0)
            Positioned(
              right: 20,
              bottom: 90,
              child: FloatingAiBubble(txs: _txs, spent: _spent, budget: _budget),
            ),
        ],
      ),
      bottomNavigationBar: isAdmin
          ? null
          : CupertinoTabBar(
              currentIndex: _currentIndex,
              onTap: (index) => setState(() => _currentIndex = index),
              items: const [
                BottomNavigationBarItem(icon: Icon(CupertinoIcons.house_fill), label: 'Tổng Quan'),
                BottomNavigationBarItem(icon: Icon(CupertinoIcons.sparkles), label: 'AI Chi Tiêu'),
              ],
            ),
    );
  }
}

// ================= TAB 1: DASHBOARD =================
class DashboardTab extends StatelessWidget {
  final UserAccount user;
  final List<ExpenseTransaction> txs;
  final double spent;
  final double budget;
  final NumberFormat formatter;
  final Function(ExpenseTransaction) onAdd;

  const DashboardTab({super.key, required this.user, required this.txs, required this.spent, required this.budget, required this.formatter, required this.onAdd});

  @override
  Widget build(BuildContext context) {
    final progress = (spent / budget).clamp(0.0, 1.0);

    return Scaffold(
      backgroundColor: const Color(0xFFF4F6F9),
      appBar: CupertinoNavigationBar(
        middle: Text('Xin chào, ${user.name}'),
        trailing: CupertinoButton(
          padding: EdgeInsets.zero,
          child: const Icon(CupertinoIcons.square_arrow_right, color: CupertinoColors.destructiveRed),
          onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const AuthScreen())),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF0066FF), Color(0xFF0040DD)]),
              borderRadius: BorderRadius.circular(24),
              boxShadow: [BoxShadow(color: const Color(0xFF0066FF).withOpacity(0.3), blurRadius: 15, offset: const Offset(0, 8))],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Tổng chi tiêu tháng này', style: TextStyle(color: Colors.white70, fontSize: 13, fontWeight: FontWeight.w500)),
                const SizedBox(height: 6),
                Text(formatter.format(spent), style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold)),
                const SizedBox(height: 18),
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(value: progress, minHeight: 8, backgroundColor: Colors.white24, valueColor: AlwaysStoppedAnimation(progress > 0.8 ? Colors.redAccent : Colors.greenAccent)),
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Hạn mức: ${formatter.format(budget)}', style: const TextStyle(color: Colors.white70, fontSize: 12)),
                    Text('${(progress * 100).toStringAsFixed(1)}%', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          const Text('Giao dịch gần đây', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          if (txs.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 40),
              child: Center(child: Text('Chưa có giao dịch nào.', style: TextStyle(color: Colors.grey))),
            )
          else
            ...txs.map((tx) => Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                  child: ListTile(
                    leading: CircleAvatar(backgroundColor: tx.category.color.withOpacity(0.15), child: Icon(tx.category.icon, color: tx.category.color)),
                    title: Text(tx.title, style: const TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: Text(DateFormat('dd/MM/yyyy • HH:mm').format(tx.date), style: const TextStyle(color: Colors.grey, fontSize: 12)),
                    trailing: Text('-${formatter.format(tx.amount)}', style: const TextStyle(color: Color(0xFFFF3B30), fontWeight: FontWeight.bold, fontSize: 15)),
                  ),
                )),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          backgroundColor: Colors.transparent,
          builder: (_) => AddExpenseBottomSheet(onSave: onAdd),
        ),
        backgroundColor: const Color(0xFF0066FF),
        icon: const Icon(CupertinoIcons.camera_viewfinder),
        label: const Text('Thêm / Quét AI'),
      ),
    );
  }
}

// ================= TAB 2: AI CHI TIÊU (MỤC RIÊNG CHO AI) =================
class AiTab extends StatelessWidget {
  final List<ExpenseTransaction> txs;
  final double spent;
  final double budget;
  final NumberFormat formatter;

  const AiTab({super.key, required this.txs, required this.spent, required this.budget, required this.formatter});

  @override
  Widget build(BuildContext context) {
    final ratio = budget > 0 ? (spent / budget) : 0.0;

    return Scaffold(
      appBar: const CupertinoNavigationBar(middle: Text('Trợ Lý AI Chi Tiêu')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF7C3AED), Color(0xFF4F46E5)]),
              borderRadius: BorderRadius.circular(24),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(CupertinoIcons.sparkles, color: Colors.white, size: 28),
                    SizedBox(width: 10),
                    Text('AI Financial Expert', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                  ],
                ),
                SizedBox(height: 10),
                Text('Hệ thống AI tự động phân tích hành vi tiêu dùng, dự báo dòng tiền và đưa ra chiến lược tối ưu tài chính cho bạn.',
                    style: TextStyle(color: Colors.white70, fontSize: 13, height: 1.4)),
              ],
            ),
          ),
          const SizedBox(height: 20),
          const Text('Báo cáo phân tích thông minh', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(ratio > 0.8 ? '🚨 Cảnh báo tài chính:' : '✅ Đánh giá an toàn:', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                const SizedBox(height: 8),
                Text(
                  ratio > 0.8
                      ? 'Bạn đã sử dụng ${(ratio * 100).toStringAsFixed(1)}% ngân sách tháng này. AI khuyến nghị bạn nên cắt giảm các khoản mua sắm ngoài kế hoạch trong 10 ngày tới.'
                      : 'Tốc độ chi tiêu hiện tại hoàn toàn nằm trong vùng kiểm soát an toàn. Bạn có thể tiết kiệm thêm khoảng ${(budget * 0.2).toStringAsFixed(0)} ₫ vào cuối tháng.',
                  style: const TextStyle(color: Colors.black87, fontSize: 13, height: 1.4),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ================= BONG BÓNG AI NỔI (FLOATING AI BUBBLE) =================
class FloatingAiBubble extends StatelessWidget {
  final List<ExpenseTransaction> txs;
  final double spent;
  final double budget;

  const FloatingAiBubble({super.key, required this.txs, required this.spent, required this.budget});

  void _showAiChatModal(BuildContext context) {
    showCupertinoModalPopup(
      context: context,
      builder: (_) => CupertinoActionSheet(
        title: const Text('Trợ Lý AI Trực Tuyến'),
        message: Text(spent > budget * 0.8 ? 'Cảnh báo: Bạn sắp vượt hạn mức chi tiêu tháng!' : 'Mọi khoản chi tiêu đang nằm trong tầm kiểm soát.'),
        actions: [
          CupertinoActionSheetAction(
            child: const Text('💡 Xin lời khuyên tiết kiệm'),
            onPressed: () {
              Navigator.pop(context);
              showCupertinoDialog(
                context: context,
                builder: (_) => CupertinoAlertDialog(
                  title: const Text('Lời khuyên từ AI'),
                  content: const Text('Hãy tập trung nấu ăn tại nhà thay vì gọi đồ ngoài và hạn chế mua sắm thương mại điện tử vào cuối tuần!'),
                  actions: [CupertinoDialogAction(child: const Text('Đã hiểu'), onPressed: () => Navigator.pop(context))],
                ),
              );
            },
          ),
        ],
        cancelButton: CupertinoActionSheetAction(
          isDefaultAction: true,
          child: const Text('Đóng'),
          onPressed: () => Navigator.pop(context),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _showAiChatModal(context),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: const Color(0xFF7C3AED),
          borderRadius: BorderRadius.circular(30),
          boxShadow: [BoxShadow(color: Colors.purple.withOpacity(0.4), blurRadius: 10, offset: const Offset(0, 4))],
        ),
        child: const Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(CupertinoIcons.sparkles, color: Colors.white, size: 18),
            SizedBox(width: 6),
            Text('Hỏi AI', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
          ],
        ),
      ),
    );
  }
}

// ================= ADMIN VIEW =================
class AdminDashboardView extends StatelessWidget {
  final UserAccount user;
  final List<ExpenseTransaction> txs;

  const AdminDashboardView({super.key, required this.user, required this.txs});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CupertinoNavigationBar(
        middle: const Text('Quản Trị Hệ Thống (Admin)'),
        trailing: CupertinoButton(
          padding: EdgeInsets.zero,
          child: const Icon(CupertinoIcons.square_arrow_right, color: CupertinoColors.destructiveRed),
          onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const AuthScreen())),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(color: Colors.purple.shade50, borderRadius: BorderRadius.circular(16)),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Khu Vực Quản Trị Viên', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.purple)),
                SizedBox(height: 8),
                Text('Kiểm soát toàn bộ dữ liệu người dùng, đồng bộ với Web Portal và giám sát trạng thái AI.'),
              ],
            ),
          ),
          const SizedBox(height: 20),
          ListTile(title: const Text('Tổng số người dùng'), trailing: const Text('1,240', style: TextStyle(fontWeight: FontWeight.bold))),
          ListTile(title: const Text('Tổng giao dịch hệ thống'), trailing: Text('${txs.length} bản ghi', style: const TextStyle(fontWeight: FontWeight.bold))),
          ListTile(title: const Text('Trạng thái Web Portal'), trailing: const Text('Online', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold))),
        ],
      ),
    );
  }
}

// ================= ADD EXPENSE BOTTOM SHEET =================
class AddExpenseBottomSheet extends StatefulWidget {
  final Function(ExpenseTransaction) onSave;
  const AddExpenseBottomSheet({super.key, required this.onSave});

  @override
  State<AddExpenseBottomSheet> createState() => _AddExpenseBottomSheetState();
}

class _AddExpenseBottomSheetState extends State<AddExpenseBottomSheet> {
  final _titleCtrl = TextEditingController();
  final _amountCtrl = TextEditingController();
  ExpenseCategory _cat = ExpenseCategory.food;
  String? _imagePath;
  bool _scanning = false;
  final ImagePicker _picker = ImagePicker();
  final TextRecognizer _ocr = TextRecognizer(script: TextRecognitionScript.latin);

  Future<void> _scan() async {
    final picked = await _picker.pickImage(source: ImageSource.camera);
    if (picked == null) return;
    setState(() { _imagePath = picked.path; _scanning = true; });

    try {
      final recognized = await _ocr.processImage(InputImage.fromFilePath(picked.path));
      double? amount;
      for (final line in recognized.blocks.expand((b) => b.lines)) {
        final txt = line.text.replaceAll(RegExp(r'[^0-9]'), '');
        if (txt.length >= 4 && txt.length <= 9) {
          final v = double.tryParse(txt);
          if (v != null && v > 1000) { amount = v; break; }
        }
      }
      setState(() {
        _scanning = false;
        if (amount != null) _amountCtrl.text = amount.toStringAsFixed(0);
        if (_titleCtrl.text.isEmpty) _titleCtrl.text = 'Hóa đơn quét AI';
      });
    } catch (_) {
      setState(() => _scanning = false);
    }
  }

  void _submit() {
    final title = _titleCtrl.text.trim();
    final amount = double.tryParse(_amountCtrl.text.replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;
    if (title.isEmpty || amount <= 0) return;

    widget.onSave(ExpenseTransaction(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      title: title,
      amount: amount,
      date: DateTime.now(),
      category: _cat,
      receiptImagePath: _imagePath,
    ));
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom + 20, top: 20, left: 20, right: 20),
      decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Center(child: Text('Thêm Khoản Chi & AI Scan', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
            const SizedBox(height: 16),
            FilledButton.tonalIcon(
              onPressed: _scanning ? null : _scan,
              icon: const Icon(CupertinoIcons.camera_viewfinder),
              label: Text(_scanning ? 'AI đang đọc hóa đơn...' : 'Chụp & Quét Hóa Đơn AI'),
            ),
            const SizedBox(height: 16),
            CupertinoTextField(controller: _amountCtrl, placeholder: 'Số tiền (VNĐ)', keyboardType: TextInputType.number, padding: const EdgeInsets.all(14)),
            const SizedBox(height: 12),
            CupertinoTextField(controller: _titleCtrl, placeholder: 'Ghi chú (Ví dụ: Ăn trưa, Cà phê...)', padding: const EdgeInsets.all(14)),
            const SizedBox(height: 16),
            const Text('Danh mục:', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: ExpenseCategory.values.map((c) => ChoiceChip(
                label: Text(c.label),
                selected: _cat == c,
                onSelected: (_) => setState(() => _cat = c),
              )).toList(),
            ),
            const SizedBox(height: 20),
            SizedBox(width: double.infinity, child: CupertinoButton.filled(onPressed: _submit, child: const Text('Lưu Khoản Chi'))),
          ],
        ),
      ),
    );
  }
}
